import {
  FirebaseApp,
  FirebaseAppModule,
  FirebaseApps,
  deleteApp,
  firebaseApp$,
  getApp,
  getApps,
  initializeApp,
  initializeServerApp,
  onLog,
  provideFirebaseApp,
  registerVersion,
  setLogLevel
} from "./chunk-F25JYEHF.js";
import {
  DEFAULT_ENTRY_NAME,
  FirebaseError,
  SDK_VERSION,
  _addComponent,
  _addOrOverwriteComponent,
  _apps,
  _clearComponents,
  _components,
  _getProvider,
  _isFirebaseApp,
  _isFirebaseServerApp,
  _registerComponent,
  _removeServiceInstance,
  _serverApps
} from "./chunk-HCHWLFPE.js";
import "./chunk-225K3NKN.js";
import "./chunk-X7GGA62K.js";
import "./chunk-LJ4VCL4A.js";
export {
  FirebaseApp,
  FirebaseAppModule,
  FirebaseApps,
  FirebaseError,
  SDK_VERSION,
  DEFAULT_ENTRY_NAME as _DEFAULT_ENTRY_NAME,
  _addComponent,
  _addOrOverwriteComponent,
  _apps,
  _clearComponents,
  _components,
  _getProvider,
  _isFirebaseApp,
  _isFirebaseServerApp,
  _registerComponent,
  _removeServiceInstance,
  _serverApps,
  deleteApp,
  firebaseApp$,
  getApp,
  getApps,
  initializeApp,
  initializeServerApp,
  onLog,
  provideFirebaseApp,
  registerVersion,
  setLogLevel
};
//# sourceMappingURL=@angular_fire_app.js.map
