export interface Reaction {
  userId: string;
  emoji: string;
}
