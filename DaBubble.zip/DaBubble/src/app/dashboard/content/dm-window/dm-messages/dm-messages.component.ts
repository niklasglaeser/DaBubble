import { Component } from '@angular/core';

@Component({
  selector: 'app-dm-messages',
  standalone: true,
  imports: [],
  templateUrl: './dm-messages.component.html',
  styleUrl: './dm-messages.component.scss'
})
export class DmMessagesComponent {

}
